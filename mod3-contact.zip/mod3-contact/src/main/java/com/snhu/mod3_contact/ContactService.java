
package com.snhu.mod3_contact;

import java.util.Map;
import java.util.HashMap;

/* // Uncomment the following lines to test in console
import java.util.ArrayList;
import java.util.Collection; */

public class ContactService {
	
	//Uncomment the following line to gain access to functions for testing in the console
	// public ContactService contactService;
	
	// Initializes the map that will hold contacts
	private Map<String, Contact> mapOfContacts;
	
	//Constructor that creates a hash map to store all key value pairs of each instance of Contact
	public ContactService() {
	        this.mapOfContacts = new HashMap<>();
	    }
	
	 public void addContact(Contact contact) {
		
		String contactID = contact.getContactID();
		
		/*// Checks if ID already exists and displays results in CONSOLE
		
		if(mapOfContacts.containsKey(contactID)) {
			System.out.println("Exists\n");
		}
		else {
			System.out.println("Doesn't exist\n");
			mapOfContacts.put(contactID, contact);
		} 
		*/
		
		if (mapOfContacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact with ID " + contactID + " already exists. Try again.");
        }
		
		// adds the new instance of contact to the map
        mapOfContacts.put(contactID, contact);
	}

	// This method deletes the contact that has an ID that matches the ID provided
	public void deleteContact(String contactID) {
        
        if (!mapOfContacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact does not exist. Try again.");
        }
    
        mapOfContacts.remove(contactID);
    }
	
	// Updates contact that has an ID that matches the ID provided
	public void updateContact(Contact updatedContact) {
		// Helps ensure that the contactID is the only attribute that's not able to be updated
        String contactID = updatedContact.getContactID();
        
        if (!mapOfContacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact doesn't exist. Try again.");
        }
        
        // Find the contact inside of map that matches the ID provided. Replaces that instance with a new one, updatedContact
        else {
        	mapOfContacts.put(contactID, updatedContact);
        }
        
       
    }
	
	//Returns the contact instance inside of the map that has an ID that matches the ID provided 
	 public Contact getContactInstance(String contactID) {
            return mapOfContacts.get(contactID);
        }
	
	/* Gets all contacts in the map. Chose to use Collection to easily iterate through the map of contacts and return their values
	public Collection<Contact> getAllContacts() {
		
        return mapOfContacts.values();
    }
	*/
	
	 
	 // Uncomment the following block of code to test in terminal console by adding contacts to the map and printing out all the values. 
/* 	

 public static void main(String[]args) {
	ContactService contactService = new ContactService();
	
	//THIS BlOCK OF CODE: adds new contacts to the map
	 
	// Adds first contact
	Contact contact1 = new Contact("1", "John", "Doe", "1234567890", "123 Main St");
	contactService.addContact(contact1);
	
	//Adds a second contact
	Contact contact2 = new Contact("2", "Sam", "Smith", "1234567148", "456 Bird St");
	contactService.addContact(contact2);
	
	//Adds a third contact
	Contact contact3 = new Contact("3", "Chad", "Williams", "1032561148", "890 Broadway St");
	contactService.addContact(contact3); 
	
	//Tries to add a duplicate; only uncomment if need to test the error response in the console
	Contact contact4 = new Contact("3", "Chad", "Williams", "1032561148", "890 Broadway St");
	contactService.addContact(contact4); 
	
	// Get all contacts from the ContactService
    Collection<Contact> contactsInMap = contactService.getAllContacts();

    // Print the values for each instance of Contact 
    System.out.println("All Contacts in the Map:");
    for (Contact contact : contactsInMap) {
        System.out.println("Contact ID: " + contact.getContactID());
        System.out.println("Name: " + contact.getFirstName()+ " " + contact.getLastName());
        System.out.println("Phone: " + contact.getPhone());
        System.out.println("Address: " + contact.getAddress() + "\n");
        System.out.println("****************\n");
    }
	
   
	

} */
}




