package com.snhu.mod3_contact;

// Initializes the Contact class
public class Contact {
	
	// Initializes the attributes
	private String contactID;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	// Sets the rules that the variable must have a length of 1-10
	private static final String CONTACT_ID_REGEX = "^.{1,10}$";
	private static final String FIRST_NAME_REGEX = "^.{1,10}$";
	private static final String LAST_NAME_REGEX = "^.{1,10}$";
	private static final String PHONE_REGEX = "^\\d{10}$";
	private static final String ADDRESS_REGEX = "^.{1,30}$";
	
	public Contact (String contactID, String firstName, String lastName, String phone, String address) {
		
		//assigns values to the Contact class's attributes
		this.contactID = contactID;
		this.firstName = firstName;
	 	this.lastName = lastName;
		this.phone = phone;
		this.address = address;
	}
	
	// Returns the value of contactID. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public String getContactID () {
		if (!contactID.matches(CONTACT_ID_REGEX)) {
            throw new IllegalArgumentException("Contact ID must be a non-null string of up to 10 characters.");
        }
		else {
			return contactID;	
		}
		
	}
	
	// Sets the value of firstName. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public void setFirstName(String firstName) {
		 if (!firstName.matches(FIRST_NAME_REGEX)) {
	            throw new IllegalArgumentException("First name must be a non-null string of up to 10 characters.");
	        }
		 else {
			 this.firstName = firstName;
		 }
		
	}
	
	// Returns the value of firstName. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public String getFirstName() {
		if (!lastName.matches(FIRST_NAME_REGEX)) {
            throw new IllegalArgumentException("First name must be a non-null string of up to 10 characters.");
        }
		else{
			return firstName;
		}
	}
	
	// Sets the value of lastName. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public void setLastName(String lastName) {
		if (!lastName.matches(LAST_NAME_REGEX)) {
            throw new IllegalArgumentException("Last name must be a non-null string of up to 10 characters.");
        }
		else {
			this.lastName = lastName;
		}
		
	}
	
	// Returns the value of lastName. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public String getLastName() {
		if (!lastName.matches(LAST_NAME_REGEX)) {
            throw new IllegalArgumentException("Last name must be a non-null string of up to 10 characters.");
        }
		else {
			return lastName;
		}
		
	}
	
	// Sets the value of phone. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public void setPhone(String phone) {
		if (!phone.matches(PHONE_REGEX)) {
            throw new IllegalArgumentException("Phone number must be a non-null string of exactly 10 digits.");
        }
		else {
			this.phone = phone;
		}
		
	}
	
	// Returns the value of phone. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public String getPhone() {
		if (!phone.matches(PHONE_REGEX)) {
            throw new IllegalArgumentException("Phone number must be a non-null string of exactly 10 digits.");
        }
		else {
			return phone;
		}
		
	}
	
	// Sets the value of address. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public void setAddress(String address) {
		
        if (!address.matches(ADDRESS_REGEX)) {
            throw new IllegalArgumentException("Address must be a non-null string of up to 30 characters.");
        }
        else {
        	this.address = address;
        }
		
	}
	
	// Returns the value of address. Will throw an illegal argument exception if the variable doesn't match the regex rules 
	public String getAddress() {
		
        if (!address.matches(ADDRESS_REGEX)) {
            throw new IllegalArgumentException("Address must be a non-null string of up to 30 characters.");
        }
        else {
        	return address;
        }
		
	}
	
	// Uncomment the following block of code to test in the console
/*
	public static void main(String[]args) {
		Contact myCon = new Contact("1234567890", "Jean", "Brown", "1234567890", "305 Bluebird");
		System.out.print("Hello! My name is ");
		System.out.print(myCon.firstName + " " + myCon.lastName);
		System.out.print("\nMy phone # is " + myCon.phone + " and address is " + myCon.address);
		System.out.print("\n and my ID is " + myCon.getContactID());
	}
	*/
}

