package com.snhu.mod3_contact;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.DisplayName;

public class ContactTest {
	
	@Test
	@DisplayName("Contact phone number has exactly 10 numbers.")
	public void validPhone () {
		Contact contact = new Contact("123450", "John", "Doe", "1234567890", "123 Main St");
		String phone= contact.getPhone();
		int phoneLength = phone.length();
		
		Assertions.assertEquals( phoneLength , 10, "The phone number has exactly 10 numbers and is valid.");
	}
	
	@Test
	@DisplayName("An error is thrown when phone number is null.")
	public void invaldPhone () {
		
        Contact contact = new Contact("1", "John", "Doe", null, "123 Main St");
        
        Assertions.assertThrows(NullPointerException.class, () -> {
    		contact.getPhone();
    	});
    }
	
	@Test
	@DisplayName("Contact address has no more than 30 chars.")
	public void validAddress () {
		Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
		String address = contact.getAddress();
		int addressLength = address.length();
		
		Assertions.assertTrue( addressLength <= 30, "The address has 30 chars or less and is valid.");
	}
	
	@Test
	@DisplayName("An error is thrown when address is null.")
	public void invalidAddress () {
		
        Contact contact = new Contact("1", "John", "Doe", "1234567890", null);
        
        Assertions.assertThrows(NullPointerException.class, () -> {
    		contact.getAddress();
    	});
    }
 
}
