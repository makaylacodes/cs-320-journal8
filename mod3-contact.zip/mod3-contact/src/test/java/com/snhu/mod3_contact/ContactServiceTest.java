package com.snhu.mod3_contact;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	@Test
	@DisplayName("New, valid contact is added to the map.")
	
	public void addValidContactTest() {
		
		Contact contact = new Contact("2", "Snoopy", "Dog", "12345667890", "457 Jay Lane");
		ContactService mapOfContacts = new ContactService();
		
		String contactID = contact.getContactID();
		
		// adds the new contact to the map
		mapOfContacts.addContact(contact);
		
		/* Calls getContactInstance and returns the Contact instance that matches the provided contact ID. The 
		   instance is stored in a new variable, newContact. This 
		*/
		Contact newContact = mapOfContacts.getContactInstance(contactID);
		
		/* Compares the original contact with the contact that was added to determine if all of the 
		   correct information was stored 
		*/
		Assertions.assertEquals(contact, newContact);
	}
	
	@Test
	@DisplayName("Contact has been rejected for having invalid attributes.")
	public void addInvalidContactTest() {
		
		//Phone number is incorrect length
		Contact contact = new Contact("2", "Snoopy", "Dog", "123456678900", "457 Jay Lane");
		ContactService mapOfContacts = new ContactService();
		
		// Adds the new contact to the map
		mapOfContacts.addContact(contact);
		
		//Asserts that an illegal argument exception is thrown to prevent the addition of an incorrectly formatted contact
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
    		mapOfContacts.addContact(contact);
    	});
	}
	
	@Test
	@DisplayName("Contact has been sucessfully deleted from the map.")
	public void deleteValidContactTest() {
		
		Contact contact = new Contact("2", "Snoopy", "Dog", "123456678900", "457 Jay Lane");
		ContactService mapOfContacts = new ContactService();
		
		String contactID = contact.getContactID();
		
		// Adds contact to the map so it's populated
		mapOfContacts.addContact(contact);

		// Deletes the recently added contact
		mapOfContacts.deleteContact(contactID);
		
		// Asserts that null is returned when searching for the ID of the recently deleted contact
		Assertions.assertNull(mapOfContacts.getContactInstance(contactID));
	}
	
	@Test
	@DisplayName("Contact sucessfully been updated.")
	public void updateContactTest() {
		
		Contact contact1 = new Contact("2", "Snoopy", "Dog", "12345667890", "457 Jay Lane");
		ContactService mapOfContacts = new ContactService();
		
		// Adds new contact to the map
		mapOfContacts.addContact(contact1);
		
		// Creates a second contact with the same ID. This will update be used to update contact1
		Contact contact2 = new Contact("2", "Shaggy", "Roo", "17345637810", "890 Blueberry St");
		
		// Calls method to update the contact with contact2's info if the ID matches
		mapOfContacts.updateContact(contact2);
		
		String contact2ID = contact2.getContactID();
		
		Contact retrivedContact = mapOfContacts.getContactInstance(contact2ID);
		
		//Asserts that the contact updated in the lists matches the original updated information and that all information has been added correctly
		Assertions.assertEquals(retrivedContact, contact2);
	}
	
}
